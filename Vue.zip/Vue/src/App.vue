<template>
  <div id="app" class="main">
      <router-view></router-view>
      <notifications group="foo" />
  </div>
</template>

<script>

export default {
  name: "app",
  data() {
    return {};
  },
};
</script>

<style>
</style>
