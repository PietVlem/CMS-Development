<template>
    <div>
        <drawer-nav>
            <div class="page-header-wrapper">
                <h1>Account</h1>
            </div>
            <div class="account">
                <div class="account__image" v-bind:style="{ 'background-image': 'url(' + userArray.picture + ')'}">
                    <div class="account__name">
                        <h2>{{userArray.user}}</h2>
                    </div>
                </div>
                
            </div>

        </drawer-nav>
    </div>
</template>

<script>
import DrawerNav from "../components/DrawerNav.vue";

export default {
  components: {
    DrawerNav
  },
  data() {
    return {
        userArray: []
    };
  },
  methods: {},
  mounted(){
      if (localStorage.getItem("userAuth") === null) {
      this.$router.push("/");
    } else {
      this.userArray = JSON.parse(localStorage.getItem("userAuth"));
    }
  }
};
</script>


<style scoped>
</style>
