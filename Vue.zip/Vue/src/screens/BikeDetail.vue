<template>
  <div>
    <drawer-nav>
      <div @click="goBack" class="back-header">
        <font-awesome-icon icon="arrow-left"/>
        <p>Back to overview</p>
      </div>
      <div class="page-header-wrapper">
        <h1>Details</h1>
      </div>
      <div class="details">
        <div class="details__image" v-bind:style="{ 'background-image': 'url( http://localhost:8888' + ebike.field_ebike_image + ')'}"></div>
        <h1>{{ebike.field_model}}</h1>
        <p>{{ebike.field_info}}</p>
        <h2>Additional information</h2>
        <ul class="spec-list">
          <li><strong>Brand:</strong> {{ebike.field_brand}}</li>
          <li><strong>Seats:</strong> {{ebike.field_seats}}</li>
        </ul>
        <p class="details__price">{{ebike.field_price}} / hour</p>
        <div class="clearfix details__button">
          <button @click="doOrder" class="clearfix">Order</button>
        </div>
      </div>
    </drawer-nav>
  </div>
</template>

<script>
import DrawerNav from "../components/DrawerNav.vue";
import axios from "axios";

export default {
  components: {
    DrawerNav: DrawerNav
  },
  data() {
    return {
      id: this.$route.params.id,
      userArray: []
    };
  },
  methods: {
    goBack() {
      this.$router.push("/bikesoverview");
    },
    doOrder() {
      const HTTP = axios.create({
        auth: {
          username: this.userArray.user,
          password: this.userArray.pass
        }
      });
      const data = {
        "type": [
          {
            "target_id": "ebike"
          }
        ],
        "field_available": [
          {
            "value": false
          }
        ],
        "field_rented_by": [
        {
            "target_id": this.userArray.id ,
            "target_type": "user",
            "target_uuid": this.userArray.uuid,
            "url": "/user/"+ this.userArray.id
          }
        ]
      };
      HTTP.patch(
        `http://localhost:8888/node/${this.id}?_format=hal_json`,
        data,
        function() {},
        {
          headers: {
            "Content-Type": "application/hal+json",
            "X-CSRF-Token": "RUsvUOIX7W7s445XyTsEiJSwpP97jD2v35EOrjQsK-8"
          }
        }
      )
      .then(response => {
        this.$notify(
          {
            group: "foo",
            title: "Order update",
            duration: 6000,
            text: `You have now ordered: ${
              this.ebike.field_model
            }. You can see your reservations in the reservations tab of your side menu.`
          },
        this.$router.push("/bikesoverview")
      );
        })
        .catch(error => {
          console.log(error.response);
        });
    }
  },
  computed: {
    ebike() {
      return this.$store.state.ebikes.find(
        x => x.nid === this.$route.params.id
      );
    }
  },
  mounted() {
    if (localStorage.getItem("userAuth") === null) {
      this.$router.push("/");
    } else {
      this.$store.dispatch("getBikes");
      this.userArray = JSON.parse(localStorage.getItem("userAuth"));
    }
  }
};
</script>


<style scoped>
</style>
