<template>
<div>
     <div id="mapid"></div>
     </div>
</template>

<script>
import axios from 'axios';

export default {
  mounted() {
    const mymap = L.map("mapid").setView([ 51.047663, 3.72], 14);
    const greenIcon = L.icon({
        iconUrl: 'http://dezwemzoo.be/pics/pin.svg',
        iconSize: [38, 95], // size of the ic
    });
    L.tileLayer(
      "https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}",
      {
        attribution:
          'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        maxZoom: 18,
        id: "mapbox.streets",
        accessToken: "pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw"
      }
    ).addTo(mymap);
    axios.get('https://datatank.stad.gent/4/mobiliteit/laadpunten.geojson').then(response => {
        response.data.coordinates.forEach(function(element) {
            var marker = L.marker([element[1], element[0]], {icon: greenIcon}).addTo(mymap)
        });
     })
  }
};
</script>
