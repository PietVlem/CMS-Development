<template>
  <div>
    <drawer-nav>
      <div class="page-header-wrapper">
        <h1>Reservations</h1>
      </div>
      <div class="reservations-list">
       <div class="reservation__item" v-for="bike in ebikes" :key="bike.nid">
         <div class="reservation__img" v-bind:style="{ 'background-image': 'url( http://localhost:8888' + bike.field_ebike_image + ')'}"></div>
         <div class="reservation__vehicule-name">
           <p>{{bike.field_model}}</p>
         </div>
         <div @click="cancelOrder(bike.nid)" class="reservation__cancel">
           <font-awesome-icon icon="times"/>
         </div>
       </div>
      </div>
    </drawer-nav>
  </div>
</template>

<script>
import DrawerNav from "../components/DrawerNav.vue";
import axios from 'axios';

export default {
  components: {
    DrawerNav: DrawerNav
  },
  data() {
    return {
      userArray: [],
    };
  },
  computed: {
    ebikes() {
      return this.$store.state.ebikes.filter(
        x => x.field_rented_by === this.userArray.user
      );
    }
  },
  methods:{
    cancelOrder(bikeId){
      const HTTP = axios.create({
        auth: {
          username: this.userArray.user,
          password: this.userArray.pass
        }
      });
      const data = {
        "type": [
          {
            "target_id": "ebike"
          }
        ],
        "field_available": [
          {
            "value": true
          }
        ],
        "field_rented_by": [
        {
           "target_id": 1,
            "target_type": "user",
            "target_uuid": "235be456-86ab-4c37-82dc-77bca06e27c4",
            "url": "/user/1"
          }
        ]
      };
      HTTP.patch(
        `http://localhost:8888/node/${bikeId}?_format=hal_json`,
        data,
        function() {},
        {
          headers: {
            "Content-Type": "application/hal+json",
            "X-CSRF-Token": "RUsvUOIX7W7s445XyTsEiJSwpP97jD2v35EOrjQsK-8"
          }
        }
      )
      .then(response => {
        this.$notify(
          {
            group: "foo",
            title: "Order update",
            duration: 6000,
            text: `Your order has been canceled`
          }
          );
        },
        this.$router.push("/bikesoverview")
        )
        .catch(error => {
          this.$notify({
            group: "foo",
            title: "Error",
            duration: 6000,
            text: `something wen wrong :( => ${error.response}.`
          })
        });
    }
  },
  mounted() {
    if (localStorage.getItem("userAuth") === null) {
      this.$router.push("/");
    } else {
      this.$store.dispatch("getBikes");
      this.userArray = JSON.parse(localStorage.getItem("userAuth"));
    }
  }
};
</script>


<style scoped>
</style>
