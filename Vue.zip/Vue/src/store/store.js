import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';

Vue.use(Vuex);

export const store = new Vuex.Store({
    /* 
    strict makes sure that you don't mutate the state from outside of the veux store
    */
    strict: true,

    state: {
        products: [
            { name: "Banana Skin", price: 20 },
            { name: "shiny star", price: 40 },
            { name: "Green star", price: 60 },
            { name: "Red Shells", price: 80 }
        ],
        posts: [],
        ebikes: [],
    },

    getters: {
        saleProducts: state => {
            var saleProducts = state.products.map(product => {
                return {
                    name: `**${product.name}**`,
                    price: product.price / 2
                }
            });
            return saleProducts;
        }
    },

    mutations: {
        reducePrice: (state, payload) => {
            state.products.forEach(product => {
                product.price -= payload;
            })
        },
        updatePostData: (state, payload) => {
            state.posts = payload;
        },
        updateEbikeData: (state, payload) => {
            state.ebikes = payload;
        }
    },

    actions: {
        reducePrice: (context, payload) => {
            setTimeout(() => {
                context.commit('reducePrice', payload);
            }, 2000)
        },
        getPosts: context => {
            axios.get('https://jsonplaceholder.typicode.com/posts').then(response => {
                context.commit('updatePostData', response.data);
            })
        },
        /*
        Login Actions
        */
        logIn: (context, payload) => {
            const HTTP = axios.create({
                auth: {
                    username: payload.user,
                    password: payload.pass
                }
            })
            axios
                .post("http://localhost:8888/user/login?_format=json", {
                    name: payload.user,
                    pass: payload.pass
                })
                .then(response => {
                    if (response.status === 200 && "csrf_token" in response.data) {
                        HTTP.get(`http://localhost:8888/user/${response.data.current_user.uid}?_format=json`).then(resUser => {
                            const authDetails = {
                                id: response.data.current_user.uid,
                                user: payload.user,
                                pass: payload.pass,
                                csrf_token: response.data.csrf_token,
                                picture: resUser.data.user_picture[0].url,
                                uuid: resUser.data.uuid[0].value
                            }
                            localStorage.setItem("userAuth", JSON.stringify(authDetails));
                        })
                    }
                });
        },
        logOut: () => {
            localStorage.removeItem("userAuth");
            location.reload();
        },
        /*
        Bike Actions
        */
        getBikes: context => {
            axios.get("http://localhost:8888/api/ebikes").then(Response => {
                context.commit('updateEbikeData', Response.data);
            })
        }
    }
})