<template>
  <vue-drawer-layout
    ref="drawerLayout">
    <div class="drawer" slot="drawer">
      <!-- 
      <a href="javascript:void(0)" class="btn" @click="handleToggleDrawer">Hide Drawer</a>
      -->
      <div class="profile">
        <div class="colored-circle">
          <div class="profile__image" v-bind:style="{ 'background-image': 'url(' + userArray.picture + ')'}"></div>
        </div>
        <span>{{userArray.user}}</span>
      </div>
      <div class="menu-item">
        <font-awesome-icon icon="bicycle"/>
        <h3><router-link to="/bikesoverview">Bike overview</router-link></h3>
      </div>
      <div class="menu-item">
        <font-awesome-icon icon="wallet"/>
        <h3><router-link to="/reservations">My reservations</router-link><br/></h3>
      </div>
      <div class="menu-item">
        <font-awesome-icon icon="map-marker-alt"/>
        <h3><router-link to="/map">Map</router-link><br/></h3>
      </div>
      <div class="menu-item">
        <font-awesome-icon icon="cog"/>
        <h3><router-link to="/account">Account</router-link><br/></h3>
      </div>
      <button @click="logOut">Log out</button>
    </div>
    
    <div class="content" slot="content">
      <div class="navbar">
        <a href="javascript:void(0)" class="btn" @click="handleToggleDrawer"><font-awesome-icon icon="bars"/></a>
      </div>
      <div class="container">
        <slot></slot>
      </div>
    </div>
  </vue-drawer-layout>
</template>

<script>
export default {
  data: function() {
    return {
      userArray: []
    };
  },
  methods: {
    handleToggleDrawer() {
      this.$refs.drawerLayout.toggle();
    },
    logOut: function() {
      this.$store.dispatch("logOut");
    }
  },
  mounted() {
    this.userArray = JSON.parse(localStorage.getItem("userAuth"));
  }
};
</script>