<template>
  <div>
    <drawer-nav>
    <div>
      <div class="page-header-wrapper">
        <h1>Available bikes</h1>
      </div>
      <div class="vehicle-list">
        <div class="vehicle" v-for="bike in ebikes" :key="bike.nid">
          <router-link :to="'/detail/' + bike.nid">
            <div class="clearfix">
              <div class="vehicle__itembar"></div>
              <div class="vehicule__image" v-bind:style="{ 'background-image': 'url( http://localhost:8888' + bike.field_ebike_image + ')'}">
              </div>
              <div class="vehicle__content">
                <span class="vehicle__model">{{bike.field_model}}</span>
                <span class="vehicle__price">{{bike.field_price}} / h</span>
              </div>
            </div>
          </router-link>
        </div>
      </div>
    </div>
    </drawer-nav>
  </div>
</template>

<script>
import DrawerNav from "../components/DrawerNav.vue";

export default {
  components: {
    DrawerNav: DrawerNav
  },
  computed: {
    ebikes() {
      return this.$store.state.ebikes.filter(x => x.field_available === "true");
    }
  },
  mounted() {
    localStorage.getItem("userAuth") === null
      ? this.$router.push("/")
      : this.$store
          .dispatch("getBikes");
  }
};
</script>


<style scoped>
</style>
