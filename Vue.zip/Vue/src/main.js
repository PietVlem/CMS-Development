import Vue from 'vue';
import App from './App.vue';
import router from './router/router';
import { store } from './store/store';
import { library } from '@fortawesome/fontawesome-svg-core';
import { faLongArrowAltRight, faBicycle, faMapMarkerAlt, faCog, faBars, faArrowLeft, faTimes, faWallet } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome';
import Notifications from 'vue-notification';
import DrawerLayout from 'vue-drawer-layout';
 
/*
Plug-ins
*/
Vue.use(DrawerLayout)
Vue.use(Notifications)

/* 
Font-awesome icons 
*/
library.add(faLongArrowAltRight);
library.add(faBicycle);
library.add(faMapMarkerAlt);
library.add(faCog);
library.add(faBars);
library.add(faArrowLeft);
library.add(faTimes);
library.add(faWallet);

Vue.component('font-awesome-icon', FontAwesomeIcon);

/*
Import style-sheet
*/
import './style/style.scss';

Vue.config.productionTip = false;

new Vue({
  router,
  store: store,
  render: h => h(App)
}).$mount('#app')
