<template>
    <div>
        <drawer-nav>
          <div class="page-header-wrapper">
            <h1>Charging points</h1>
          </div>
          <Map/>
        </drawer-nav>
    </div>
</template>

<script>
import DrawerNav from "../components/DrawerNav.vue";
import Map from '../components/Map.vue';

export default {
  components: {
    DrawerNav,
    Map
  },
  data() {
    return {

    };
  },
  methods: {},
  mounted(){
    if (localStorage.getItem("userAuth") === null) {
      this.$router.push("/");
    }
  }
};
</script>


<style scoped>
</style>
