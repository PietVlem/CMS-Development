<template>
<div class="container">
  <div class="login-wrapper">
    <div class="login">
      <img src="../assets/logo.svg">
      <h1><span class="greenText">Bee</span>lectric</h1>
      <form v-on:submit.prevent>
        <div>
          <input class="input" type="text" placeholder="Username" v-model="username">
        </div>
        <div>
          <input class="input" type="password" placeholder="Password" v-model="pass">
        </div>
        <div class="clearfix">
          <button @click="logIn" class="button is-primary loginbtn"><font-awesome-icon icon="long-arrow-alt-right"/></button>
        </div>
      </form>
    </div>
  </div>
</div>
</template>

<script>
export default {
  data() {
    return {
      username: "",
      pass: ""
    };
  },
  methods: {
    logIn: function() {
      this.$store
        .dispatch("logIn", {
          user: this.username,
          pass: this.pass
        })
        .then(
          setTimeout(() => {
            this.$router.push("/BikesOverview")
          }, 500)
          );
    }
  },
  mounted() {
    if(localStorage.getItem("userAuth") !== null){
      this.$router.push("/BikesOverview")
    }
  }
};
</script>



<style scoped>
</style>
