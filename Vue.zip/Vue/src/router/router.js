import Vue from 'vue';
import Router from 'vue-router';

/*
Import Screens
*/
import Login from '../screens/Login';
import BikesOverview from '../screens/BikesOverview';
import BikeDetail from '../screens/BikeDetail';
import Reservations from '../screens/Reservations';
import ChargingPoints from '../screens/ChargingPoints';
import Account from '../screens/Account';

Vue.use(Router)

export default new Router({
    routes: [
        {
            path: '/',
            name: 'Login',
            component: Login
        },
        {
            path: '/bikesoverview',
            name: 'BikesOverview',
            component: BikesOverview
        },
        {
            path: '/detail/:id',
            name: 'bikePage',
            component: BikeDetail
        },
        {
            path: '/reservations',
            name: 'reservations',
            component: Reservations
        },
        {
            path: '/map',
            name: 'Charging Points',
            component: ChargingPoints
        },
        {
            path: '/account',
            name: 'Account',
            component: Account
        }
    ]
})